//
//  ViewController.swift
//  MapCombine
//
//  Created by Yi Hwei Huang on 2018/10/2.
//  Copyright © 2018年 tw.iii.org. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces

class SpotAddController: UIViewController , CLLocationManagerDelegate , GMSMapViewDelegate, GMSAutocompleteViewControllerDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    
  
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnTurnOnCamera: UIButton!
    @IBOutlet weak var btnOpenPhotoLibrary: UIButton!
    @IBOutlet weak var txtSpotDescription: UITextField!
    @IBOutlet weak var txtSpotName: UITextField!
    @IBOutlet weak var mapCenterPin: UIImageView!
    @IBOutlet var googleMapsView: GMSMapView!
    @IBOutlet var lblAddress: UILabel!
    
    // VARIABLES
    var locationManager = CLLocationManager()
    var imgPicked=UIImage()
    var lat:String=""
    var lon:String=""
    var addressArray=[String]()
    var imgDefault=UIImage()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()
        
       // self.btnOpenPhotoLibrary.setImage(#imageLiteral(resourceName: "gallery2.png"), for: .normal)
        
        self.txtSpotName.delegate=self as! UITextFieldDelegate
        self.txtSpotDescription.delegate=self as! UITextFieldDelegate
        
        
        initGoogleMaps()
    }
    
    override func viewDidAppear(_ animated: Bool) {
       super.viewDidAppear(animated)
        btnOpenPhotoLibrary.setImage(#imageLiteral(resourceName: "gallery2"), for: .normal)
        if btnOpenPhotoLibrary.tag==4{
             btnOpenPhotoLibrary.setImage(imgPicked, for: .normal)
        }
       
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func initGoogleMaps() {
        
        let camera = GMSCameraPosition.camera(withLatitude: -33.86, longitude: 151.20, zoom: 6.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        mapView.isMyLocationEnabled = true
        self.googleMapsView.camera = camera
        
        self.googleMapsView.delegate = self as! GMSMapViewDelegate
        self.googleMapsView.isMyLocationEnabled = true
        self.googleMapsView.settings.myLocationButton = true
        
        
        // Creates a marker in the center of the map.
//        let marker = GMSMarker()
//        marker.position = CLLocationCoordinate2D(latitude: -33.86, longitude: 151.20)
//        marker.title = "Sydney"
//        marker.snippet = "Australia"
//        marker.map = mapView
    }
    
    // MARK: CLLocation Manager Delegate
    
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while get location \(error)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last
        
        let camera = GMSCameraPosition.camera(withLatitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!, zoom: 17.0)
        
        self.googleMapsView.animate(to: camera)
        self.locationManager.stopUpdatingLocation()
        
    }
    
    // MARK: GMSMapview Delegate
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        self.googleMapsView.isMyLocationEnabled = true
        reverseGeocodeCoordinate(position.target)
    }
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        
        self.googleMapsView.isMyLocationEnabled = true
        if (gesture) {
            mapView.selectedMarker = nil
        }
        
    }
    
    private func reverseGeocodeCoordinate(_ coordinate: CLLocationCoordinate2D) {
        
        // 1
        let geocoder = GMSGeocoder()
        
        // 2
        geocoder.reverseGeocodeCoordinate(coordinate) { response, error in
            
            //            self.lblAddress.unlock()
            
            guard let address = response?.firstResult(), var lines = address.lines
            
            else {return}
            
            // 3
            self.lat=String(format: "%f", coordinate.latitude)
            self.lon=String(format: "%f", coordinate.longitude)
            self.lblAddress.text = lines.joined(separator: "\n")
//            self.lblAddress.text = lines.joined(separator: "\n")+"\nlat:\(self.lat)"+" lon: \(self.lon)"
            self.addressArray.append(self.lblAddress.text!)
            //            print("======****=======")
            //            print(coordinate)
            
            
            // 4
            UIView.animate(withDuration: 0.25) {
                self.view.layoutIfNeeded()
            }
        }
    }
   
    
    // MARK: GOOGLE AUTO COMPLETE DELEGATE
    
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        
        var camera = GMSCameraPosition.camera(withLatitude: place.coordinate.latitude, longitude: place.coordinate.longitude, zoom: 15.0)
        self.googleMapsView.camera = camera
        
        self.dismiss(animated: true, completion: nil) // dismiss after select place
        
//        let marker = GMSMarker()
//        marker.position = CLLocationCoordinate2D(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)
//        marker.title = place.name
//        marker.snippet = "Aaaa"
//        camera = GMSCameraPosition.camera(withLatitude:place.coordinate.latitude , longitude: place.coordinate.longitude, zoom: 6.0)
//        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
//        marker.map = mapView
        
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        
        print("ERROR AUTO COMPLETE \(error)")
        
    }
    
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        self.dismiss(animated: true, completion: nil) // when cancel search
    }
    

    let myImagePicker: UIImagePickerController = UIImagePickerController()
    
    @IBAction func btnOpenPhotoLibrary_Click(_ sender: Any) {
        
                myImagePicker.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
                myImagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
                self.present(myImagePicker, animated: true, completion: nil)
    }
    
    
    @IBAction func btnTurnOnCamera_Click(_ sender: Any) {
    }
    
    //editing did begin
    @IBAction func txtSpotName_EditingDidBegin(_ sender: Any) {
        
    }
    
    
   //edit did begin
   
    @IBAction func txtSpotDescription_EditingDidBegin(_ sender: Any) {
        
    }
    
    
    @IBAction func txtSpotName_DidEndOnExit(_ sender: Any) {
        
    }
    
    
    @IBAction func txtSpotDescription_DidEndOnExit(_ sender: Any) {
        
    }
    
    
    //search btn click
    
    @IBAction func Searchbtn_Click(_ sender: Any) {
        let autoCompleteController = GMSAutocompleteViewController()
        autoCompleteController.delegate = self as? GMSAutocompleteViewControllerDelegate
        
        self.locationManager.startUpdatingLocation()
        self.present(autoCompleteController, animated: true, completion: nil)
    }
    
    
    @IBAction func btnAdd_Click(_ sender: Any) {
        
        if txtSpotDescription==nil{
            txtSpotDescription.text=""
        }
        
        if txtSpotName.text != nil{
            
            let PostData:[String:Any]=["PosX":"\(lat)","PosY":"\(lon)","Address":"\(lblAddress.text!)","Name":"\(txtSpotName.text!)","Descrption":"\(txtSpotDescription.text!)"]
            
            let strurl:String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot?token=75df7ef0afcb4c29a5149b89dc76f7c4"
            //"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot"
            let strPerEsc: String = strurl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
            let myURL = URL(string: strPerEsc)!
            let SessionConfig = URLSessionConfiguration.default
            let session = URLSession(configuration: SessionConfig, delegate: nil, delegateQueue: nil)
            var request = URLRequest(url: myURL)
            
            request.httpMethod = "POST"
            request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
            
            guard let httpbody = try? JSONSerialization.data(withJSONObject: PostData, options: []) else {return}
            request.httpBody = httpbody
            
            let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                if let response = response{
                    print(response)
                }
                
                if let data = data{ //body裡面的東西
                    do{
                        let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                        print(json)
                    }catch{
                        print(error)
                    }
                }
            })
            dataTask.resume()
        
        }
        //PosX /Y Address/Description
//        print(lat+"==========")
//        print(lon)
        print(lblAddress.text)
    }
    
    
    @IBAction func btnClear_Click(_ sender: Any) {
        
    }
    
    
    //textfield shift
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.txtSpotName.resignFirstResponder()//正在接收使用者輸入的東西-->收鍵盤
        self.txtSpotDescription.resignFirstResponder()
        
    }
    
    //開始編輯文字方塊
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //使用者在輸入文字時，整體畫面上移，好讓鍵盤跟輸入區域都可以同時呈現
        var shift:CGFloat=0.0//位移值
        if textField.tag==1{
            shift=165.0

        }else if textField.tag==2{
           shift=180.0
        }
        
        self.view.center=CGPoint(x: self.view.center.x, y: self.view.center.y-shift)
    }
    
    //結束編輯文字輸入方塊
    func textFieldDidEndEditing(_ textField: UITextField) {
        var shift:CGFloat=0.0//位移值
        if textField.tag==1{
            shift=165.0
        }else if textField.tag==2{
            shift=180.0
        }
        
        self.view.center=CGPoint(x: self.view.center.x, y: self.view.center.y+shift)
    }
    
    
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        //確認選取
        let tookImage: UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        imgPicked = tookImage
        picker.dismiss(animated: true, completion: nil)
        btnOpenPhotoLibrary.tag=4
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //取消
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    
}




